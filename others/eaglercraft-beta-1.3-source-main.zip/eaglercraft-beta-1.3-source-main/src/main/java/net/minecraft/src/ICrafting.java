package net.minecraft.src;
// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.

// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) braces deadcode 

public interface ICrafting {

	public abstract void func_20159_a(CraftingInventoryCB craftinginventorycb, int i, ItemStack itemstack);

	public abstract void func_20158_a(CraftingInventoryCB craftinginventorycb, int i, int j);
}
