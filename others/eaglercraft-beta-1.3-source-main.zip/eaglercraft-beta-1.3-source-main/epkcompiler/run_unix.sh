#!/bin/sh
java -jar CompilePackage.jar "../lwjgl-rundir/resources" "../javascript/assets.epk"